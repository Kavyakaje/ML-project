
## IRIS FLOWER CLASSIFICATION


### IMPORT LIBRARIES


```python
import sys
import scipy
import numpy
import matplotlib
import pandas
import sklearn

```


```python
import pandas
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
```

### LOADING DATASET USING PANDAS


```python
dataset=pandas.read_csv('iris.csv')
```

### DATA PREPROCESSING


```python
dataset.isnull().sum()
```




    sepal.length    0
    sepal.width     0
    petal.length    0
    petal.width     0
    variety         0
    dtype: int64




```python
print(dataset.head(20))
```

        sepal.length  sepal.width  petal.length  petal.width variety
    0            5.1          3.5           1.4          0.2  Setosa
    1            4.9          3.0           1.4          0.2  Setosa
    2            4.7          3.2           1.3          0.2  Setosa
    3            4.6          3.1           1.5          0.2  Setosa
    4            5.0          3.6           1.4          0.2  Setosa
    5            5.4          3.9           1.7          0.4  Setosa
    6            4.6          3.4           1.4          0.3  Setosa
    7            5.0          3.4           1.5          0.2  Setosa
    8            4.4          2.9           1.4          0.2  Setosa
    9            4.9          3.1           1.5          0.1  Setosa
    10           5.4          3.7           1.5          0.2  Setosa
    11           4.8          3.4           1.6          0.2  Setosa
    12           4.8          3.0           1.4          0.1  Setosa
    13           4.3          3.0           1.1          0.1  Setosa
    14           5.8          4.0           1.2          0.2  Setosa
    15           5.7          4.4           1.5          0.4  Setosa
    16           5.4          3.9           1.3          0.4  Setosa
    17           5.1          3.5           1.4          0.3  Setosa
    18           5.7          3.8           1.7          0.3  Setosa
    19           5.1          3.8           1.5          0.3  Setosa
    


```python
print(dataset.describe())
```

           sepal.length  sepal.width  petal.length  petal.width
    count    150.000000   150.000000    150.000000   150.000000
    mean       5.843333     3.057333      3.758000     1.199333
    std        0.828066     0.435866      1.765298     0.762238
    min        4.300000     2.000000      1.000000     0.100000
    25%        5.100000     2.800000      1.600000     0.300000
    50%        5.800000     3.000000      4.350000     1.300000
    75%        6.400000     3.300000      5.100000     1.800000
    max        7.900000     4.400000      6.900000     2.500000
    


```python
print(dataset.groupby('variety').size())
```

    variety
    Setosa        50
    Versicolor    50
    Virginica     50
    dtype: int64
    


```python
dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
plt.show()
```


![png](output_11_0.png)



```python
dataset.hist()
plt.show()
```


![png](output_12_0.png)



```python
scatter_matrix(dataset)
plt.show()
```


![png](output_13_0.png)


### SPLITTING DATA INTO TRAIN AND TEST


```python
array = dataset.values
X = array[:,0:4]
Y = array[:,4]
validation_size = 0.20
seed = 7
X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, test_size=validation_size, random_state=seed)
```


```python
seed = 7
scoring = 'accuracy'
```

### FITTING THE MODEL DATASET


```python
models = []
models.append(('SVM', SVC(gamma='auto')))
# evaluate each model in turn
results = []
names = []
for name, model in models:
	kfold = model_selection.KFold(n_splits=10, random_state=seed)
	cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring=scoring)
	results.append(cv_results)
	names.append(name)
	msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
	print(msg)

```

    SVM: 0.991667 (0.025000)
    


```python
fig = plt.figure()
fig.suptitle('Algorithm Comparison')
ax = fig.add_subplot(111)
plt.boxplot(results)
ax.set_xticklabels(names)
plt.show()
```


![png](output_19_0.png)


### PREDICITING TARGET AND CONFUSION MATRIX FOR TEST DATA


```python
knn= SVC()
knn.fit(X_train, Y_train)
predictions = knn.predict(X_validation)
print(accuracy_score(Y_validation, predictions))
print(confusion_matrix(Y_validation, predictions))
```

    0.9333333333333333
    [[ 7  0  0]
     [ 0 10  2]
     [ 0  0 11]]
    

    C:\Users\Preeti Kamat\Anaconda3\lib\site-packages\sklearn\svm\base.py:196: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)
    


```python

```
